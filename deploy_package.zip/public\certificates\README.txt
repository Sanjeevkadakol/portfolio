HOW TO ADD LOCAL CERTIFICATES

1. Copy your certificate PDF files into this folder (e:\porteasy\public\certificates\).
   Example: my-certificate.pdf

2. Go to the Admin Dashboard (http://localhost:5173/admin/skills).

3. Create or Edit a Skill (Certificate).

4. In the "Certificate Link" field, enter the path starting with /certificates/.
   Example: /certificates/my-certificate.pdf

5. Save the skill.

Now, when visitors click on the certificate card on your website, it will open your local PDF file.
